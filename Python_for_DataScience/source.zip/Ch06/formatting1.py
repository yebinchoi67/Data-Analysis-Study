print(1, 2, 3)
print("a" + " " + "b" + " " + "c")
print("%d %d %d" % (1, 2, 3))
print("{} {} {}".format("a", "b", "c"))
