print('%s %s' % ('one', 'two'))
print('%d %d' % (1, 2))
