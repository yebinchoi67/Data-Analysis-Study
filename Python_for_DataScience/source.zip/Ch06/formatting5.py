age = 40; name='Sungchul Choi'
print("I'm {0} years old.".format(age))
print("My name is {0} and {1} years old.".format(name, age))
print("Product: {0}, Price per unit: {1:.2f}.".format("Apple", 5.243))
