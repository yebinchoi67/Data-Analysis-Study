print("I eat %d apples." % 3)
print("I eat %s apples." % "five")
