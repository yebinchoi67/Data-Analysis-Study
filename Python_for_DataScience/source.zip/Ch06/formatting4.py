number = 3
day = "three"
print("I ate %d apples. I was sick for %s days." % (number, day))
