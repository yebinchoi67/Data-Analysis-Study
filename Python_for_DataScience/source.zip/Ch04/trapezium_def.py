def addition(x, y):
    return x + y

def multiplication(x, y):
    return x * y

def divided_by_2(x):
    return x / 2
