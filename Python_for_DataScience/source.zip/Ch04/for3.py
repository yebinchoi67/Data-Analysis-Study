for looper in range(100):
    print("hello")
