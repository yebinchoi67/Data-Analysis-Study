for i in ['americano', 'latte', 'frappuccino']:
    print(i)
