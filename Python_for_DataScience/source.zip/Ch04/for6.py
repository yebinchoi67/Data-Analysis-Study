for i in range(1, 10, 2):   # 1부터 9까지 2씩 증가시키면서 반복문 수행
    print(i)
