pront(x + y)        # Print가 아닌 Pront로 작성
korean = "ACE"
print(Korean)       # k는 소문자
