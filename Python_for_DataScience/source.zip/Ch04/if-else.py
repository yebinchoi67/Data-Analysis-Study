print("Tell me your age?")
myage = int(input())                    # 나이를 입력받아 myage 변수에 할당
if myage < 30:                          # myage가 30 미만일 때
    print("Welcome to the Club.")
else:                                   # myage가 30 이상일 때
    print("Oh! No. You are not accepted.")
