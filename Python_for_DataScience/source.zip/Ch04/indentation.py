x = 2
 y = 5
print(x + y)
