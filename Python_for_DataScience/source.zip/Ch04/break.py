for i in range(10):
    if i == 5: break        # i가 5가 되면 반복 종료
    print(i)
print("End of Program")     # 반복 종료 후 ‘End of Program’ 출력
