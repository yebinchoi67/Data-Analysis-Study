for i in 'abcdefg':
    print(i)
