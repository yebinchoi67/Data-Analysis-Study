for i in range(10):
    if i == 5: continue     # i가 5가 되면 i를 출력하지 않음
    print(i)
print("End of Program")     # 반복 종료 후 ‘End of Program’ 출력
