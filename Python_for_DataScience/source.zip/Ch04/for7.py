for i in range(10, 1, -1):      # 10부터 2까지 1씩 감소시키면서 반복문 수행
    print(i)
