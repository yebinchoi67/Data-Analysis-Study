a = 5
if (a > 3):
    print("Hello World")
    print("Hello TEAMLAB")
if (a > 4):
    print("Hello World")
    print("Hello TEAMLAB")
if (a > 5):
    print("Hello World")
    print("Hello TEAMLAB")
