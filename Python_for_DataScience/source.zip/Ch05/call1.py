def f(x):
    y = x
    x = 5
    return y * y

x = 3
print(f(x))
print(x)
