def asterisk_test(a, b, *args):
    print(args)

print(asterisk_test(1, 2, 3, 4, 5))
