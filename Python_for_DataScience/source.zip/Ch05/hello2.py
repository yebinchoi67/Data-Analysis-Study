def print_hello():
    print("Hello World")
    print("Hello TEAMLAB")

a = 5
if (a > 3):
    print_hello()

if (a > 4):
    print_hello()

if (a > 5):
    print_hello()
