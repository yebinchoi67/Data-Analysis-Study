def print_something(my_name, your_name):
    print("Hello {0}, My name is {1}".format(your_name, my_name))

print_something("Sungchul", "TEAMLAB")
print_something(your_name = "TEAMLAB", my_name = "Sungchul")
