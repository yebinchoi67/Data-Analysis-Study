def f(x):
    return 2 * x + 7

print(f(2))
