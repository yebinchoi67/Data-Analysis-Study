from factorial_calculator import factorial
print(factorial_calculator.factorial(6))
