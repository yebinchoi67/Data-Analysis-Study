from collections import defaultdict

d = defaultdict(lambda: 0)          # Default 값을 0으로 설정
print(d["first"])
