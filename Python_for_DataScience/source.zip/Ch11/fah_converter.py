def covert_c_to_f(celcius_value):
    return celcius_value * 9.0 / 5 + 32
