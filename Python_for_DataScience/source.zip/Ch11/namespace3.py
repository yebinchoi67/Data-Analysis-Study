from fah_converter import *
print(covert_c_to_f(41.6))
