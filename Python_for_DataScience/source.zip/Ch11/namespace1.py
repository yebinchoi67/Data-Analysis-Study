import fah_converter as fah
print(fah.covert_c_to_f(41.6))
