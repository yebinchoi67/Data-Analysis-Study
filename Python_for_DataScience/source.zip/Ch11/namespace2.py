from fah_converter import covert_c_to_f
print(covert_c_to_f(41.6))
