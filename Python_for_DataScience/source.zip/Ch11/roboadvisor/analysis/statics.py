def statics_test():
    print("statics")
