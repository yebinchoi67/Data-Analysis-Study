def series_test():
    print("series")
