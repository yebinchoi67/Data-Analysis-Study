from . import series
from . import statics

__all__ = ['series', 'statics']
