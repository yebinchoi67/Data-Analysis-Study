def scrap_test():
    print("scrap")
