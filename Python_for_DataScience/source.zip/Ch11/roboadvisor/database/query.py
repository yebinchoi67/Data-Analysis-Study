def query_test():
    print("query")
