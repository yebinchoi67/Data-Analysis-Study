print("Enter your name:")
somebody = input()                    # 콘솔 창에서 입력한 값을 somebody에 저장
print("Hi", somebody, "How are you today?")
