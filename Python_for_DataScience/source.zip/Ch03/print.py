temperature = float(input("온도를 입력하세요: "))          # 입력 시 바로 형 변환
print(temperature)
