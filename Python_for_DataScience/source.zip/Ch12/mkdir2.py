import os
os.mkdir("log")

if not os.path.isdir("log"):
    os.mkdir("log")
