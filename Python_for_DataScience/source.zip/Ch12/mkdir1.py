import os
os.mkdir("log")
