f = open("dream.txt", "r")
contents = f.read()
print(contents)
f.close()
