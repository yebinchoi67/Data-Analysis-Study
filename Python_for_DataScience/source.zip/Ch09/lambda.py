f = lambda x, y: x + y
print(f(1, 4))
