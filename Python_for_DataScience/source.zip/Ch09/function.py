def f(x, y):
    return x + y

print(f(1, 4))
