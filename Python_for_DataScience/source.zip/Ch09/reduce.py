x = 0
for y in [1, 2, 3, 4, 5]:
    x += y

print(x)
